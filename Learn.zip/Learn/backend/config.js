export const PORT = 5555;

export const mongoDBURL =
'mongodb+srv://priyanshijain:9ABBSZ2Qn32JKevv@bookstore.7zpnznh.mongodb.net/?retryWrites=true&w=majority&appName=BookStore'

//9ABBSZ2Qn32JKevv

// Please create a free database for yourself.
// This database will be deleted after tutorial