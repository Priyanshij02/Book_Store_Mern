import React from 'react'

const DeleteBooks = () => {
  return (
    <div>DeleteBooks</div>
  )
}

export default DeleteBooks